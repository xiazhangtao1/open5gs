#!/usr/bin/env python3
"""Recompute four-user results from raw iperf receivers and host schedstat."""
import json
import math
import pathlib
import re
import statistics

root = pathlib.Path(__file__).resolve().parent
runs = []
for summary in sorted((root / 'default').glob('*-summary.json')):
    value = json.loads(summary.read_text())
    args, label = value['args'], value['label']
    base = summary.parent
    state = json.loads((base / ('state.json' if (base / 'state.json').exists() else 'state-cleaned.json')).read_text())
    sessions = state['sessions']
    assert len(sessions) == 4 and args['processes'] == 4
    protocol = 'UDP' if label.startswith('udp-') else 'TCP'
    rx, tx, timestamps = [], [], []
    for i in range(args['processes']):
        client = json.loads((base / f'{label}-{i}.json').read_text())
        assert 'error' not in client
        assert client['start']['test_start']['protocol'] == protocol
        assert len(client['start']['connected']) == args['streams']
        source, dest = sessions[i]['pdu']['ipv4'], '198.19.0.2'
        if protocol == 'UDP' and args['direction'] == 'dl':
            source, dest = dest, source
        assert all(c['local_host'] == source and c['remote_host'] == dest
                   for c in client['start']['connected'])
        stamp = client['start']['timestamp']
        timestamps.append(stamp.get('timemillisecs', stamp['timesecs'] * 1000) / 1000)
        if protocol == 'UDP':
            receive, send = client['end']['sum_received'], client['end']['sum_sent']
            server = json.loads((base / f'{label}-server-{i}.json').read_text())
            independent = server['end']['sum_received']
            assert all(receive[k] == independent[k] for k in
                       ('bytes', 'seconds', 'bits_per_second', 'packets', 'lost_packets'))
        else:
            receive_side = client if args['direction'] == 'dl' else client['server_output_json']
            send_side = client['server_output_json'] if args['direction'] == 'dl' else client
            receive, send = receive_side['end']['sum_received'], send_side['end']['sum_sent']
        assert receive['bytes'] > 0 and receive['seconds'] > 0
        assert math.isclose(receive['bits_per_second'], receive['bytes'] * 8 / receive['seconds'], rel_tol=1e-6)
        rx.append(receive)
        tx.append(send)
    total = sum(v['bits_per_second'] for v in rx) / 1e6
    assert math.isclose(total, value['receiver_mbps'], rel_tol=1e-12)
    for i, user in enumerate(value['per_user']):
        assert user['supi'] == sessions[i]['supi'] and user['seid'] == sessions[i]['pdu']['upf_seid']
        assert math.isclose(user['receiver_mbps'], rx[i]['bits_per_second'] / 1e6, rel_tol=1e-12)
    if protocol == 'UDP':
        loss = sum(v['lost_packets'] for v in rx) * 100 / sum(v['packets'] for v in rx)
        assert math.isclose(loss, value['lost_percent'], abs_tol=1e-12)
        assert all(0 <= v['lost_packets'] <= v['packets'] for v in rx)
    before = json.loads((base / f'{label}-before-snapshot.json').read_text())
    after = json.loads((base / f'{label}-after-snapshot.json').read_text())
    def identities(snap):
        return sorted((u['supi'], p['ipv4'], p['upf_seid'], p['psi'], p['n3'])
                      for u in snap['pdu']['items'] for p in u.get('pdu', []))
    assert identities(before) == identities(after) and len(identities(before)) == 4
    counters = []
    for s in sessions:
        aa = next(v for v in before['rates']['rows'] if v['supi'] == s['supi'])
        bb = next(v for v in after['rates']['rows'] if v['supi'] == s['supi'])
        assert aa['seid'] == bb['seid'] == int(s['pdu']['upf_seid'])
        assert aa['worker'] == bb['worker'] == 0
        delta = {d + '_bytes': bb[d + '_bytes'] - aa[d + '_bytes'] for d in ('ul', 'dl')}
        if value['mode'] == 'core':
            assert delta[args['direction'] + '_bytes'] > 1000000
        counters.append({'supi': s['supi'], 'seid': aa['seid'], 'worker': aa['worker'], **delta})
    metrics = [json.loads(line) for line in (base / f'{label}-metrics.jsonl').read_text().splitlines()]
    start = max(timestamps) + args['omit'] + (5 if args['seconds'] >= 15 else 1)
    end = min(timestamps) + args['omit'] + args['seconds'] - (2 if args['seconds'] >= 15 else 1)
    steady = [m for m in metrics if start <= m['wall_seconds'] <= end]
    cpu = {}
    if len(steady) >= 2:
        aa, bb = steady[0], steady[-1]
        seconds = (bb['monotonic_ns'] - aa['monotonic_ns']) / 1e9
        for role in ('upf', 'vpp'):
            a, b = aa['roles'][role], bb['roles'][role]
            def cfs(row):
                return {k: int(n) for k, n in (x.split() for x in row['cpu_stat'].splitlines())}
            x, y = cfs(a), cfs(b)
            threads = []
            for tid, t in a['threads'].items():
                z = b['threads'][tid]
                assert t['affinity'] == z['affinity']
                threads.append({'tid': int(tid), 'comm': t['comm'], 'affinity': t['affinity'],
                                'cpu_percent': (z['runtime_ns'] - t['runtime_ns']) / seconds / 1e7,
                                'runqueue_wait_percent': (z['runqueue_wait_ns'] - t['runqueue_wait_ns']) / seconds / 1e7})
            cpu[role] = {'seconds': seconds, 'threads': threads, 'cpuset': a['cpuset'],
                         'cpu_quota_us': int(a['cpu_quota_us']),
                         'cfs_delta': {k: y[k] - x[k] for k in x},
                         'memory_failcnt_delta': int(b['memory_failcnt']) - int(a['memory_failcnt']),
                         'memory_bytes_min': min(int(m['roles'][role]['memory_bytes']) for m in steady),
                         'memory_bytes_max': max(int(m['roles'][role]['memory_bytes']) for m in steady)}
    def interfaces(output):
        result, current = {}, None
        for line in output.splitlines():
            match = re.match(r'^(\S+)\s+\d+\s+(?:up|down)\s+', line)
            if match:
                current = match[1]
                result[current] = {}
            counter = re.search(r'\b(rx packets|tx packets|rx bytes|tx bytes|drops|rx-error|tx-error)\s+(\d+)\s*$', line)
            if current and counter:
                result[current][counter[1]] = int(counter[2])
        return result
    def errors(output):
        result = {}
        for line in output.splitlines():
            match = re.match(r'^\s*(\d+)\s+(\S+)\s+(.*?)\s+(?:error|warn|info)\s*$', line)
            if match:
                key = match[2] + ': ' + match[3]
                result[key] = result.get(key, 0) + int(match[1])
        return result
    packet_deltas, error_deltas = {}, {}
    for role in ('core', 'ran'):
        x, y = interfaces(before[role + '_show_interface']), interfaces(after[role + '_show_interface'])
        packet_deltas[role] = {iface: {k: y[iface].get(k, 0)-v for k, v in fields.items()}
                              for iface, fields in x.items() if iface in y}
        x, y = errors(before[role + '_show_errors']), errors(after[role + '_show_errors'])
        error_deltas[role] = {k: v-x.get(k, 0) for k, v in y.items() if v-x.get(k, 0)}
    value.update(protocol=protocol, raw_directory='default', start_skew_seconds=max(timestamps)-min(timestamps),
                 steady_cpu=cpu, session_counter_deltas=counters, interface_counter_deltas=packet_deltas, error_counter_deltas=error_deltas,
                 jain_receiver_fairness=total**2/(len(rx)*sum((v['bits_per_second']/1e6)**2 for v in rx)),
                 all_users_pass_low_loss=protocol=='UDP' and all(u['lost_percent'] <= .1 for u in value['per_user']))
    runs.append(value)
selection = json.loads((root / 'selection.json').read_text()) if (root / 'selection.json').exists() else {}
selected = {k: next(v for v in runs if v['label'] == label) for k, label in selection.items()}
for key, value in selected.items():
    assert value['mode'] == 'core' and value['args']['seconds'] == 30
    if value['protocol'] == 'UDP':
        assert value['all_users_pass_low_loss'] and value['lost_percent'] <= .1
stats = {}
for direction in ('ul','dl'):
    values=[r['receiver_mbps'] for r in runs if r['protocol']=='TCP' and r['mode']=='core' and
            r['args']['direction']==direction and r['args']['seconds']==30 and r['args']['streams']==4]
    if values:
        stats[direction]={'runs':len(values),'mean_mbps':statistics.mean(values),'min_mbps':min(values),
                          'max_mbps':max(values),'median_mbps':statistics.median(values),
                          'population_stddev_mbps':statistics.pstdev(values)}
result={'scope':'4 distinct users, one PDU/PFCP session each; default core CPU/queues; directions measured separately',
        'units':'application payload decimal Mbit/s','udp_loss_threshold_percent':.1,
        'udp_threshold_applies_to':'aggregate and every individual user',
        'git_baseline':json.loads((root/'environment.json').read_text())['git_commit'],
        'final_selected':selected,'tcp_30s_statistics':stats,'runs':runs,
        'validation':'receiver bytes/time/rate recomputed; UDP independent server logs matched; four stable SMF/PFCP sessions and per-user counters checked'}
(root/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
for r in runs:
    print(r['label'],f"rx={r['receiver_mbps']:.3f}",f"loss={r['lost_percent']}",
          'all-user-pass='+str(r['all_users_pass_low_loss']))
print('VALIDATED',len(runs),'runs')
