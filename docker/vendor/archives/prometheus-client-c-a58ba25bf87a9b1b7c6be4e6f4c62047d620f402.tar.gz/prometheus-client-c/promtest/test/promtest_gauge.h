/**
 * Copyright 2019-2020 DigitalOcean Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "prom.h"

#ifndef PROMTEST_GAUGE_H
#define PROMTEST_GAUGE_H

extern prom_gauge_t *foo_gauge;

int promtest_gauge_setup(void);
int promtest_gauge_teardown(void);

void promtest_gauge(void);

#endif  // PROMTEST_GAUGE_H
